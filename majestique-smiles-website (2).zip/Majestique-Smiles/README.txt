MAJESTIQUE SMILES WEBSITE DOWNLOAD

ready-to-host/
  The production website. Upload the contents of this folder to the root of a static web host.

editable-source/
  The React + Vite source project. With Node.js and npm installed, run:
    npm install
    npm run dev
  To rebuild the static website, run:
    npm run build
  The rebuilt site will be in dist/.

Appointment requests open a prefilled WhatsApp message; the visitor must tap Send, and the clinic must reply to confirm. The address is included in the directions search, but confirm the exact map pin before publishing if precision is important.
