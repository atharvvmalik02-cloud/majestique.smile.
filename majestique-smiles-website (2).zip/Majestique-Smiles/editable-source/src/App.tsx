import { useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  Heart,
  MapPin,
  MessageCircle,
  Menu,
  Phone,
  ShieldCheck,
  Sparkles,
  Star,
  X,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

const CLINIC_PHONE_DISPLAY = '07799361606';
const CLINIC_PHONE_LINK = 'tel:+917799361606';
const CLINIC_WHATSAPP_NUMBER = '917799361606';
const CLINIC_ADDRESS =
  'Mauli Building, opposite Babasai Dairy and Gayatri Veg Restaurant, Sindhu Nagar, Sector 25, Pradhikaran, Nigdi, PCMC, Maharashtra';
const MAPS_DESTINATION = `Majestique Smiles Orthodontic and Multispeciality Dental Clinic, ${CLINIC_ADDRESS}`;
const MAPS_DIRECTIONS_URL = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(MAPS_DESTINATION)}`;

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [formNotice, setFormNotice] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [whatsappUrl, setWhatsappUrl] = useState('');

  const closeMenu = () => setMenuOpen(false);
  const submitRequest = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const message = [
      'Hello Majestique Smiles, I would like to request an appointment.',
      `Name: ${String(formData.get('name') ?? '').trim()}`,
      `Contact: ${String(formData.get('contact') ?? '').trim()}`,
      `Preferred date: ${String(formData.get('date') ?? '').trim()}`,
      `Visit topic: ${String(formData.get('reason') ?? '').trim()}`,
      'Please let me know what times are available.',
    ].join('\n');
    const requestUrl = `https://wa.me/${CLINIC_WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    setWhatsappUrl(requestUrl);
    window.open(requestUrl, '_blank', 'noopener,noreferrer');
    setSubmitted(true);
    setFormNotice('WhatsApp opened with your appointment request. Review the message and tap Send there to contact the clinic. Your appointment is confirmed only after the clinic replies.');
  };

  return (
    <main className="site-shell min-h-[100dvh]">
      <div className="topline px-5 py-2.5 text-center">
        Thoughtful dental care, close to home <span className="mx-2 opacity-50">·</span> Nigdi, PCMC
        <span className="mx-2 opacity-50">·</span>
        <a className="topline-link" href={CLINIC_PHONE_LINK} aria-label={`Call Majestique Smiles at ${CLINIC_PHONE_DISPLAY}`}>Call {CLINIC_PHONE_DISPLAY}</a>
      </div>
      <header className="nav-wrap relative z-20 px-5 md:px-10">
        <div className="mx-auto flex max-w-[1320px] items-center justify-between py-4">
          <a href="#home" className="flex items-center gap-3" aria-label="Majestique Smiles home" onClick={closeMenu}>
            <span className="brand-mark"><Sparkles size={19} strokeWidth={1.4} aria-hidden="true" /></span>
            <span className="leading-tight">
              <span className="block serif text-[23px] tracking-[-.02em]">Majestique Smiles</span>
              <span className="mt-0.5 block text-[9px] uppercase tracking-[.2em] text-[#6c7b71]">Orthodontic & Multispeciality Dental Clinic</span>
            </span>
          </a>
          <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">
            <a className="nav-link" href="#care">Our care</a>
            <a className="nav-link" href="#approach">Our approach</a>
            <a className="nav-link" href="#reviews">Reviews</a>
            <a className="nav-link" href="#visit">Find us</a>
          </nav>
          <a href="#appointment" className="button-primary hidden md:inline-flex">Request a visit <ArrowUpRight size={15} /></a>
          <button type="button" className="inline-flex h-11 w-11 items-center justify-center border border-[#d9d2c5] md:hidden" aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'} aria-expanded={menuOpen} onClick={() => setMenuOpen((open) => !open)}>
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
        {menuOpen && (
          <nav className="mobile-menu menu-panel flex flex-col gap-1 p-3 md:hidden" aria-label="Mobile navigation">
            {[['Our care', '#care'], ['Our approach', '#approach'], ['Reviews', '#reviews'], ['Find us', '#visit'], ['Request a visit', '#appointment']].map(([label, href]) => (
              <a key={href} className="px-4 py-3 text-sm hover:bg-[#eee9de]" href={href} onClick={closeMenu}>{label}<ChevronRight className="float-right mt-0.5" size={16} /></a>
            ))}
          </nav>
        )}
      </header>

      <section id="home" className="relative px-5 pb-16 pt-10 md:px-10 md:pb-24 md:pt-16">
        <div className="mx-auto grid max-w-[1240px] items-center gap-10 md:grid-cols-[1.02fr_.98fr] md:gap-8">
          <div className="reveal relative z-10 pb-3 md:pb-12">
            <p className="eyebrow mb-6">A neighbourhood clinic in Nigdi</p>
            <h1 className="serif max-w-[670px] text-[clamp(3.35rem,7vw,6.7rem)] leading-[.91] tracking-[-.045em]">
              A little more at ease, <em className="text-[#bd775e]">every time</em> you smile.
            </h1>
            <p className="mt-7 max-w-[450px] text-[15px] leading-7 text-[#63736a]">
              Orthodontic and multispeciality dental care, with space for your questions and your pace. Start with a conversation; we’ll take it one step at a time.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a href="#appointment" className="button-primary">Request an appointment <ArrowRight size={15} /></a>
              <a href="#care" className="button-outline">Explore our care</a>
            </div>
            <div className="mt-10 flex items-center gap-3 border-t border-[#d9d2c5] pt-5 text-sm text-[#63736a]">
              <MapPin className="shrink-0 text-[#bd775e]" size={17} />
              <span>Mauli Building, Sindhu Nagar, Nigdi</span>
              <a href="#visit" className="ml-auto whitespace-nowrap text-xs font-semibold uppercase tracking-[.1em] text-[#244b45] underline decoration-[#bd775e] underline-offset-4">Get directions</a>
            </div>
          </div>
          <div className="reveal reveal-delay relative mx-auto w-full max-w-[590px] md:ml-auto">
            <div className="hero-portrait aspect-[.91] bg-[#e8d9c8]">
              <img src="/clinic-hero.jpg" alt="A woman smiling naturally in warm, soft light" className="h-full w-full object-cover object-[58%_center]" />
            </div>
            <div className="hero-note absolute -bottom-5 left-0 max-w-[250px] bg-[#fdfaf4] p-5 md:-left-12 md:bottom-10">
              <div className="flex items-start gap-3">
                <span className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-full bg-[#e9e3d6] text-[#244b45]"><Heart size={16} /></span>
                <div>
                  <p className="serif text-[21px] leading-tight">Care that listens first.</p>
                  <p className="mt-2 text-xs leading-5 text-[#6c7b71]">Clear conversations. Considered next steps.</p>
                </div>
              </div>
            </div>
            <span className="absolute -right-2 top-7 hidden text-[10px] uppercase tracking-[.2em] text-[#78857b] [writing-mode:vertical-rl] md:block">Feel good about your next step</span>
          </div>
        </div>
        <a href="#care" className="mx-auto mt-14 flex w-fit items-center gap-2 text-[10px] uppercase tracking-[.2em] text-[#748077] md:mt-20"><ArrowDown size={14} /> Take a look around</a>
      </section>

      <section id="care" className="bg-[#eae5d9] px-5 py-20 md:px-10 md:py-28">
        <div className="mx-auto max-w-[1180px]">
          <div className="grid gap-9 md:grid-cols-[.85fr_1.15fr] md:items-end">
            <div>
              <p className="eyebrow mb-5">Care, considered</p>
              <h2 className="serif max-w-[490px] text-5xl leading-[.98] tracking-[-.03em] md:text-6xl">The right care starts with <em className="text-[#bd775e]">being heard.</em></h2>
            </div>
            <p className="max-w-[470px] pb-1 text-[15px] leading-7 text-[#63736a] md:ml-auto">Every smile is different. We make room for a proper conversation, so you can understand your options and decide what feels right for you.</p>
          </div>
          <div className="mt-14 grid gap-x-10 gap-y-11 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { n: '01', title: 'Orthodontics', copy: 'A thoughtful look at alignment and the options that may suit your smile.', icon: <Sparkles size={20} /> },
              { n: '02', title: 'Everyday dental care', copy: 'Support for check-ups, prevention and keeping your oral health on track.', icon: <ShieldCheck size={20} /> },
              { n: '03', title: 'Restorative care', copy: 'Talk through ways to care for teeth that need attention or repair.', icon: <Heart size={20} /> },
              { n: '04', title: 'A broader conversation', copy: 'Multispeciality care that helps you explore your needs in one place.', icon: <ChevronRight size={20} /> },
            ].map((item) => (
              <article key={item.n} className="service-card pt-5">
                <div className="flex items-center justify-between"><span className="service-icon">{item.icon}</span><span className="text-[10px] tracking-[.14em] text-[#8b9389]">{item.n}</span></div>
                <h3 className="serif mt-6 text-[27px] leading-none">{item.title}</h3>
                <p className="mt-3 text-sm leading-6 text-[#63736a]">{item.copy}</p>
              </article>
            ))}
          </div>
          <p className="mt-10 border-l-2 border-[#bd775e] pl-4 text-xs leading-5 text-[#6c7b71]">The care that is suitable for you can only be determined after a consultation. Please ask the clinic about specific treatments.</p>
        </div>
      </section>

      <section id="approach" className="px-5 py-20 md:px-10 md:py-28">
        <div className="mx-auto grid max-w-[1180px] gap-12 md:grid-cols-[.92fr_1.08fr] md:items-center">
          <div className="relative max-w-[500px]">
            <div className="absolute -left-5 -top-5 h-32 w-32 border-l border-t border-[#bd775e]"></div>
            <div className="clinic-promise relative bg-[#244b45] px-8 py-10 text-[#f8f3e9] md:px-12 md:py-14">
              <span className="serif text-[88px] leading-none text-[#d99578]">“</span>
              <p className="serif -mt-3 max-w-[390px] text-[34px] leading-[1.08] md:text-[42px]">You deserve to feel comfortable asking every question.</p>
              <div className="mt-8 h-px w-12 bg-[#d99578]"></div>
              <p className="mt-4 text-[10px] uppercase tracking-[.18em] text-[#d5d8ca]">Our promise to every patient</p>
            </div>
            <span className="absolute -bottom-5 -right-4 h-20 w-20 rounded-full border border-[#c4aa91]"></span>
          </div>
          <div className="md:pl-8">
            <p className="eyebrow mb-5">A calmer kind of care</p>
            <h2 className="serif max-w-[550px] text-5xl leading-[.98] tracking-[-.03em] md:text-6xl">No rush. No judgement. Just <em className="text-[#bd775e]">your next step.</em></h2>
            <p className="mt-6 max-w-[510px] text-[15px] leading-7 text-[#63736a]">A dental visit can bring up questions. We believe the first step should feel simple: tell us what’s on your mind, understand what comes next, and take the time you need.</p>
            <ul className="mt-8 space-y-4">
              {['We listen to what matters to you', 'We explain options in clear, everyday language', 'You stay part of every decision'].map((line) => (
                <li key={line} className="flex items-center gap-3 text-sm"><span className="grid h-6 w-6 place-items-center rounded-full bg-[#eae5d9] text-[#244b45]"><Check size={13} /></span>{line}</li>
              ))}
            </ul>
            <a href="#appointment" className="mt-8 inline-flex items-center gap-3 text-xs font-bold uppercase tracking-[.12em] text-[#244b45] underline decoration-[#bd775e] underline-offset-8">Let’s start with a conversation <ArrowRight size={15} /></a>
          </div>
        </div>
      </section>

      <section id="reviews" className="bg-[#d9e1da] px-5 py-16 md:px-10 md:py-20">
        <div className="mx-auto max-w-[1180px]">
          <div>
            <p className="eyebrow mb-5">Patient voices</p>
            <h2 className="serif max-w-[430px] text-5xl leading-[.98] tracking-[-.03em] md:text-6xl">Trust is built <em className="text-[#bd775e]">together.</em></h2>
          </div>
          <div className="clinic-rating mt-8 flex flex-wrap items-center gap-x-5 gap-y-2 border-y border-[#244b45]/20 py-5">
            <span className="serif text-5xl leading-none">5.0</span>
            <div>
              <div className="flex gap-1 text-[#a45a00]" role="img" aria-label="5 out of 5 stars">
                {Array.from({ length: 5 }, (_, index) => <Star key={index} size={18} fill="currentColor" strokeWidth={1.5} />)}
              </div>
              <p className="mt-1 text-xs font-semibold">5.0 out of 5 <span className="font-normal">· rating supplied by the clinic</span></p>
            </div>
          </div>
          <div className="mt-7 grid gap-5 lg:grid-cols-2">
            <article className="review-card bg-white p-6 md:p-8">
              <div className="mb-4 flex gap-1 text-[#a45a00]" aria-label="5 out of 5 stars">
                {Array.from({ length: 5 }, (_, index) => <Star key={index} size={16} fill="currentColor" strokeWidth={1.5} />)}
              </div>
              <blockquote className="text-sm leading-7 text-[#102a43]">“I came to Pune from Hyderabad, and I am glad to find this clinic. The doctors were very friendly and helped me understand my oral hygiene better. I have then got my father treated, too. Thanks for helping me with an aesthetic smile.”</blockquote>
              <p className="mt-5 text-xs font-bold uppercase tracking-[.12em] text-[#40566f]">Patient review</p>
            </article>
            <article className="review-card bg-white p-6 md:p-8">
              <div className="mb-4 flex gap-1 text-[#a45a00]" aria-label="5 out of 5 stars">
                {Array.from({ length: 5 }, (_, index) => <Star key={index} size={16} fill="currentColor" strokeWidth={1.5} />)}
              </div>
              <blockquote className="text-sm leading-7 text-[#102a43]">“Very much satisfied with the services and care given. I suggest everyone to come here instead of wasting time elsewhere. Very affordable and quick treatments done here. Thank you.”</blockquote>
              <p className="mt-5 text-xs font-bold uppercase tracking-[.12em] text-[#40566f]">Shravan Reddy</p>
            </article>
          </div>
          <div className="clinic-note mt-5 border-l-4 border-[#a45a00] bg-white/75 p-5 md:p-6">
            <p className="text-[10px] font-bold uppercase tracking-[.15em] text-[#7a3d00]">A note from the clinic</p>
            <p className="serif mt-2 text-2xl leading-snug">We’re glad when every patient leaves with clearer answers, thoughtful care, and a smile they feel good about.</p>
          </div>
        </div>
      </section>

      <section id="visit" className="px-5 py-20 md:px-10 md:py-28">
        <div className="mx-auto max-w-[1180px]">
          <div className="grid gap-10 md:grid-cols-[.8fr_1.2fr] md:items-end">
            <div>
              <p className="eyebrow mb-5">Find your way here</p>
              <h2 className="serif max-w-[420px] text-5xl leading-[.98] tracking-[-.03em] md:text-6xl">Right here in <em className="text-[#bd775e]">Nigdi.</em></h2>
            </div>
            <p className="max-w-[450px] text-sm leading-6 text-[#63736a] md:ml-auto">Look for Mauli Building, opposite Babasai Dairy and Gayatri Veg Restaurant. Open the map for directions to the clinic.</p>
          </div>
          <div className="mt-10 grid overflow-hidden border border-[#d9d2c5] md:grid-cols-[1.05fr_.95fr]">
            <div className="map-grid relative min-h-[290px] md:min-h-[390px]" role="img" aria-label="Illustrative, not-to-scale location guide for Majestique Smiles near Mauli Building in Sindhu Nagar, Nigdi">
              <div className="absolute left-[48%] top-[38%] h-16 w-16 rounded-full bg-[#bd775e]/15"></div>
              <div className="absolute left-[51%] top-[43%] grid h-10 w-10 place-items-center rounded-full bg-[#244b45] text-[#fff8ed] shadow-lg"><MapPin size={19} /></div>
              <div className="map-label absolute left-[calc(51%+24px)] top-[39%] px-4 py-3">
                <span className="block text-[9px] uppercase tracking-[.14em] text-[#40566f]">Clinic destination</span>
                <span className="serif mt-1 block whitespace-nowrap text-[20px]">Majestique Smiles</span>
              </div>
              <span className="absolute bottom-4 left-4 bg-white/95 px-2 py-1 text-[9px] uppercase tracking-[.13em] text-[#40566f]">Mauli Building · Sector 25 · Nigdi</span>
            </div>
            <div className="clinic-location flex flex-col justify-center bg-[#f0ece3] p-7 md:p-10">
              <p className="section-label">Majestique Smiles</p>
              <h3 className="serif mt-4 text-[32px] leading-tight">Orthodontic & Multispeciality Dental Clinic</h3>
              <address className="mt-5 not-italic text-sm leading-7 text-[#40566f]">{CLINIC_ADDRESS}.</address>
              <a className="button-primary mt-7 w-fit" href={MAPS_DIRECTIONS_URL} target="_blank" rel="noreferrer">Directions to Majestique Smiles <ArrowUpRight size={15} /></a>
              <p className="mt-4 text-[11px] text-[#40566f]">Google Maps opens directions using the clinic name and the landmarks above. If the pin looks different, call us at <a className="font-bold underline underline-offset-2" href={CLINIC_PHONE_LINK}>{CLINIC_PHONE_DISPLAY}</a> before travelling.</p>
            </div>
          </div>
        </div>
      </section>

      <section id="appointment" className="bg-[#244b45] px-5 py-20 text-[#f8f3e9] md:px-10 md:py-28">
        <div className="mx-auto grid max-w-[1180px] gap-12 md:grid-cols-[.82fr_1.18fr]">
          <div>
            <p className="eyebrow !text-[#e5a88d]">Your first step</p>
            <h2 className="serif mt-5 max-w-[440px] text-5xl leading-[.96] tracking-[-.03em] md:text-6xl">A visit begins with a <em className="text-[#e5a88d]">hello.</em></h2>
            <p className="mt-6 max-w-[390px] text-sm leading-6 text-[#d4ddd4]">Share a few details and continue to WhatsApp to send your appointment request. The clinic will reply to confirm availability.</p>
            <div className="mt-9 flex items-start gap-3 border-t border-[#f8f3e9]/20 pt-5 text-xs leading-5 text-[#d4ddd4]"><ShieldCheck className="mt-0.5 shrink-0 text-[#e5a88d]" size={17} />Please don’t include private medical details. Your name, contact, preferred date and visit topic will be added to a WhatsApp draft for you to review and send.</div>
            <div className="mt-5 flex flex-wrap gap-3">
              <a href={CLINIC_PHONE_LINK} className="contact-action"><Phone size={16} />Call {CLINIC_PHONE_DISPLAY}</a>
              <a href={`https://wa.me/${CLINIC_WHATSAPP_NUMBER}`} target="_blank" rel="noreferrer" className="contact-action"><MessageCircle size={16} />WhatsApp us</a>
            </div>
          </div>
          <div className="appointment-card bg-[#f7f3eb] p-6 text-[#263e3a] md:p-9">
            {submitted ? (
              <div className="flex min-h-[350px] flex-col justify-center" role="status" aria-live="polite">
                <span className="grid h-12 w-12 place-items-center rounded-full bg-[#e4e9df] text-[#244b45]"><Check size={22} /></span>
                <h3 className="serif mt-6 text-4xl">Thank you for reaching out.</h3>
                <p className="mt-3 max-w-[460px] text-sm leading-6 text-[#63736a]">{formNotice}</p>
                <a href={whatsappUrl} target="_blank" rel="noreferrer" className="button-primary mt-6 w-fit"><MessageCircle size={16} />Open WhatsApp again</a>
                <button type="button" className="button-outline mt-7 w-fit" onClick={() => { setSubmitted(false); setFormNotice(''); }}>Make another request</button>
              </div>
            ) : (
              <form onSubmit={submitRequest} className="space-y-5">
                <div className="mb-7">
                  <p className="section-label">Appointment request</p>
                  <h3 className="serif mt-2 text-3xl">Tell us a little about your visit.</h3>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <label className="block text-xs font-semibold">Your name <span className="text-[#bd775e]">*</span><input className="field mt-2 text-sm" name="name" autoComplete="name" placeholder="Name" required /></label>
                  <label className="block text-xs font-semibold">How can the clinic contact you? <span className="text-[#bd775e]">*</span><input className="field mt-2 text-sm" name="contact" autoComplete="email" placeholder="Phone or email" required /></label>
                  <label className="block text-xs font-semibold">Preferred date <span className="text-[#bd775e]">*</span><input className="field mt-2 text-sm" type="date" name="date" min={new Date().toISOString().split('T')[0]} required /></label>
                  <label className="block text-xs font-semibold">What would you like to discuss? <span className="text-[#bd775e]">*</span>
                    <select className="field mt-2 text-sm" name="reason" defaultValue="" required>
                      <option value="" disabled>Select a topic</option>
                      <option>Orthodontic consultation</option><option>General dental care</option><option>Another dental concern</option><option>Not sure yet</option>
                    </select>
                  </label>
                </div>
                <label className="flex items-start gap-3 text-xs leading-5 text-[#40566f]"><input type="checkbox" className="mt-1 accent-[#244b45]" required />I agree to open WhatsApp with these details. I’ll review the message and tap Send myself.</label>
                <button className="button-primary w-full sm:w-auto" type="submit"><MessageCircle size={16} />Continue to WhatsApp</button>
                <p className="text-[10px] leading-4 text-[#40566f]">Your request is not sent until you tap Send in WhatsApp. The clinic must reply to confirm an appointment.</p>
              </form>
            )}
          </div>
        </div>
      </section>

      <section className="px-5 py-20 md:px-10 md:py-24">
        <div className="mx-auto grid max-w-[1180px] gap-10 md:grid-cols-[.68fr_1.32fr]">
          <div>
            <p className="eyebrow mb-5">A few answers</p>
            <h2 className="serif text-5xl leading-[.98] tracking-[-.03em] md:text-6xl">Before you <em className="text-[#bd775e]">visit.</em></h2>
            <p className="mt-5 max-w-[300px] text-sm leading-6 text-[#63736a]">A little more clarity can make that first step feel easier.</p>
          </div>
          <div>
            {[
              ['How do I request an appointment?', 'Complete the form and continue to WhatsApp. Review the prefilled message and tap Send to contact Majestique Smiles. The clinic will reply to confirm your appointment.'],
              ['What are the clinic timings? Is it open 24 hours?', 'The clinic is open 24 hours, as shared by the clinic. Please call or WhatsApp 07799361606 before visiting to check dentist availability and arrange your appointment.'],
              ['What should I expect at a first visit?', 'A first visit is a good time to share what you are looking for and ask questions. The clinic can advise what to bring and what to expect when you contact them directly.'],
              ['Does the clinic provide orthodontic care?', 'The clinic is identified as an orthodontic and multispeciality dental clinic. Please contact them directly to ask about the specific treatment options that may be appropriate for you.'],
              ['Where exactly is the clinic?', `The clinic is at ${CLINIC_ADDRESS}. Use the directions link above to open Google Maps.`],
              ['Can I see patient reviews here?', 'This page shares patient feedback provided by the clinic, plus a 5.0 out of 5 rating supplied by the clinic.'],
            ].map(([question, answer]) => <details className="faq-row group py-5" key={question}><summary className="flex items-center justify-between gap-6 text-[15px] font-semibold">{question}<span className="sr-only">Toggle answer</span></summary><p className="max-w-[650px] pt-4 pr-8 text-sm leading-6 text-[#63736a]">{answer}</p></details>)}
          </div>
        </div>
      </section>

      <footer className="border-t border-[#d9d2c5] px-5 py-8 md:px-10">
        <div className="mx-auto flex max-w-[1180px] flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
          <a href="#home" className="flex items-center gap-3" aria-label="Majestique Smiles, back to top"><span className="brand-mark h-9 w-9"><Sparkles size={16} /></span><span className="serif text-xl">Majestique Smiles</span></a>
          <div className="flex flex-col gap-1 text-[11px] leading-5 text-[#40566f]">
            <a href={CLINIC_PHONE_LINK} className="flex items-center gap-2 font-semibold"><Phone size={14} />{CLINIC_PHONE_DISPLAY}</a>
            <span>{CLINIC_ADDRESS}</span>
          </div>
          <a href="#home" className="flex items-center gap-2 text-[10px] uppercase tracking-[.15em] text-[#244b45]">Back to top <ArrowDown className="rotate-180" size={13} /></a>
        </div>
      </footer>
    </main>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
